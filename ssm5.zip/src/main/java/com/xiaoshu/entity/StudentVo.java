package com.xiaoshu.entity;

public class StudentVo extends Student {

	public String cname;

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}
}
